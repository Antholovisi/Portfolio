import React from 'react';
import './Footer.scss';

// Définition du composant Footer
function Footer() {
  // Rendu du composant Footer
  return (
    <div className="footer">
      <div className="footerContent">
        <span>
          © 2024 LOVISI Anthony. All <span className="second-line">rights reserved</span>
        </span>
      </div>
    </div>
  );
}

// Exportation du composant Footer
export default Footer;
