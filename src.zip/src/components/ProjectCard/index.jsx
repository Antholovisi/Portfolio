import React from 'react';
import './ProjectCard.scss';

const ProjectCard = ({ title, description, link }) => {
  return (
    <div className="project-card">
      <h3>{title}</h3>
      <p>{description}</p>
      <a href={link}>Voir le projet</a>
    </div>
  );
};

export default ProjectCard;
