import React from 'react';
import './Header.scss';

const Header = () => {
  return (
    <header className="navbar">
      <nav>
        <ul>
          <li><a href="#home">Acceuil</a></li>
          <li><a href="#portfolio">Portfolio</a></li>
          <li><a href="#compétences">Compétences</a></li>
          <li><a href="#about">A propos</a></li>
          <li><a href="#contact">Contact</a></li>
        </ul>
      </nav>
    </header>
  );
};

export default Header;
