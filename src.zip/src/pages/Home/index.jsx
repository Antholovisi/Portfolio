import React from 'react';
import './Home.scss';
import profilePicture from '../../assets/images/animaux.jpg';

const Home = () => {
  return (
    <section className="home-section">
      <div className="content">
        <div className="profile">
          <img src={profilePicture} alt="Votre Nom" className="profile-picture" />
          <div className="intro">
            <h1>Bienvenue, je suis Anthony Lovisi</h1>
            <p>Développeur web frontend spécialisé en React. J'adore créer des expériences utilisateur fluides et modernes.</p>
          </div>
        </div>
        
        <div className="buttons">
          <a href="#contact" className="cta-button">Me contacter</a>
          <a href="/cv.pdf" className="cta-button" target="_blank" rel="noopener noreferrer">Mon CV</a>
        </div>
      </div>
    </section>
  );
};

export default Home;
