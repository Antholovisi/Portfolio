import React from 'react';
import './Portfolio.scss';

const Portfolio = () => {
  return (
    <div className="portfolio-section">
      <h1>Mon Portfolio</h1>
      <p>Voici quelques projets que j'ai réalisés :</p>
      <ul>
        <li>Projet 1</li>
        <li>Projet 2</li>
        <li>Projet 3</li>
      </ul>
    </div>
  );
};

export default Portfolio;
