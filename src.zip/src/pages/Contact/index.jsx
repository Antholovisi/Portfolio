import React from 'react';
import './Contact.scss';

const Contact = () => {
  return (
    <div className="contact-section">
      <h1>Contact</h1>
      <p>Vous pouvez me contacter à cette adresse email : example@example.com.</p>
    </div>
  );
};

export default Contact;
