import React from 'react';
import './Skills.scss';

const Portfolio = () => {
  return (
    <div className="Skills">
      <h1>Compétences</h1>
      <p>Voici quelques technologies que j'utilise dans mes projets :</p>
    </div>
  );
};

export default Portfolio;